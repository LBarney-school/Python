#imports and runs a few functions from the School package
from School.courses import fall_courses
from School.students import student_record
from School.teachers import get_teacher_1

student_record()
fall_courses()
get_teacher_1()
