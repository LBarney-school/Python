#prints information on a student
def student_record():
    print("Name:Liam Barney")
    print("Age:41")
    print("Gender:Male")
    print("Student ID:12345")
    print("\n")

#prints GPA of a student
def student_grade():
    print("Name:Liam Barney")
    print("Student ID:12345")
    print("GPA:3.8")
    print("\n")
