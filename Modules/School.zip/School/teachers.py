#prints information on a teacher
def get_teacher_1():
    print("Name:Anna Thayer")
    print("Email:ATHAYER@blueridgectc.edu")
    print("Classes: SDE-195, SDE-188")
    print("\n")

#prints information on a different teacher
def get_teacher_2():
    print("Name: Don Heumphreus")
    print("Email: DHEUMPHR@blueridgectc.edu")
    print("Classes: None")
    print("\n")
