# prints a small course catalog
def fall_courses():
    print("SDE-195: Programming in Python")
    print("CNET-211: Switch")
    print("CYBR-192: CYBR Practicum")
    print("CYBR-210: Intrusion Detection")
    print("\n")


# prints a small course catalog
def spring_courses():
    print("CNET-131: Introduction to Networks")
    print("CYBR-160: Information Security Fundament")
    print("IT-244: Cloud/Virtualization")
    print("SDE-188: Intro to Programming Logic")
    print("\n")
