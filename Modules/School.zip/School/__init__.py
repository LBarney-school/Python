print("School Package Loaded")
print("\n")
